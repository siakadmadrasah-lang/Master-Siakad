import{c as x,r as v,aD as d,aH as P,aB as _,j as g,w as $}from"./index-pIDUfEEF.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=x("Book",[["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",key:"k3hazp"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=x("Lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]);var j=Object.defineProperty,o=(e,r)=>j(e,"name",{value:r,configurable:!0}),b="Progress",m=100,[w,G]=_(b),[L,R]=w(b),D=v.forwardRef(o(function(r,i){const{__scopeProgress:l,value:s=null,max:a,getValueLabel:V=N,...y}=r;(a||a===0)&&!c(a)&&console.error(h(`${a}`,"Progress"));const t=c(a)?a:m;s!==null&&!p(s,t)&&console.error(I(`${s}`,"Progress"));const n=p(s,t)?s:null,M=u(n)?V(n,t):void 0;return d.jsx(L,{scope:l,value:n,max:t,children:d.jsx(P.div,{"aria-valuemax":t,"aria-valuemin":0,"aria-valuenow":u(n)?n:void 0,"aria-valuetext":M,role:"progressbar","data-state":f(n,t),"data-value":n??void 0,"data-max":t,...y,ref:i})})},"Progress")),k="ProgressIndicator",A=v.forwardRef(o(function(r,i){const{__scopeProgress:l,...s}=r,a=R(k,l);return d.jsx(P.div,{"data-state":f(a.value,a.max),"data-value":a.value??void 0,"data-max":a.max,...s,ref:i})},"ProgressIndicator"));function N(e,r){return`${Math.round(e/r*100)}%`}o(N,"defaultGetValueLabel");function f(e,r){return e==null?"indeterminate":e===r?"complete":"loading"}o(f,"getProgressState");function u(e){return typeof e=="number"}o(u,"isNumber");function c(e){return u(e)&&!isNaN(e)&&e>0}o(c,"isValidMaxNumber");function p(e,r){return u(e)&&!isNaN(e)&&e<=r&&e>=0}o(p,"isValidValueNumber");function h(e,r){return`Invalid prop \`max\` of value \`${e}\` supplied to \`${r}\`. Only numbers greater than 0 are valid max values. Defaulting to \`${m}\`.`}o(h,"getInvalidMaxError");function I(e,r){return`Invalid prop \`value\` of value \`${e}\` supplied to \`${r}\`. The \`value\` prop must be:
  - a positive number
  - less than the value passed to \`max\` (or ${m} if no \`max\` prop is set)
  - \`null\` or \`undefined\` if the progress is indeterminate.

Defaulting to \`null\`.`}o(I,"getInvalidValueError");var E=D,S=A;const B=v.forwardRef(({className:e,value:r,...i},l)=>g.jsxDEV(E,{ref:l,className:$("relative h-4 w-full overflow-hidden rounded-full bg-secondary",e),...i,children:g.jsxDEV(S,{className:"h-full w-full flex-1 bg-primary transition-all",style:{transform:`translateX(-${100-(r||0)}%)`}},void 0,!1,{fileName:"/app/applet/src/components/ui/progress.tsx",lineNumber:18,columnNumber:5},void 0)},void 0,!1,{fileName:"/app/applet/src/components/ui/progress.tsx",lineNumber:10,columnNumber:3},void 0));B.displayName=E.displayName;export{H as B,O as L,B as P};
