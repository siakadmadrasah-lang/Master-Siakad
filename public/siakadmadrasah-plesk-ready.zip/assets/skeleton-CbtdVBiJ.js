import{j as t,w as n}from"./index-D-fFMPr4.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
