import{c as t,r as o}from"./index-CFT4ahmL.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=t("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=t("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);var n=Object.defineProperty,a=(e,r)=>n(e,"name",{value:r,configurable:!0}),c=o.createContext(void 0);function i(e){const r=o.useContext(c);return e||r||"ltr"}a(i,"useDirection");export{C,u as a,i as u};
