import{j as t,E as n}from"./index-CFT4ahmL.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
