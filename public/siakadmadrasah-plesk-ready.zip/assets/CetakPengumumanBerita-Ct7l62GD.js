import{c as w,u as E,a4 as P,r as o,t as j,j as e,h as c,F as y,a7 as C}from"./index-BXQbyKFI.js";import{K as V}from"./KopSurat-CU4Ttax8.js";import{P as B}from"./PenandatanganDokumen-Bi8PLiO0.js";import{A}from"./arrow-left-B97mjRj_.js";import{P as _}from"./printer-6i_pSZxl.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=w("Video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]),O=({item:t,type:p,onClose:b})=>{const{settings:f}=E(),{requirePrintAuth:N}=P(),[x,I]=o.useState(!0),[g,T]=o.useState(!0),[h,L]=o.useState(!0),[l,K]=o.useState("portrait");o.useEffect(()=>(document.body.classList.add("portal-print-active"),()=>{document.body.classList.remove("portal-print-active")}),[]);const m=f.pengaturan_cetak||{margin_top:1,margin_right:1,margin_bottom:1,margin_left:1};let a=[];if(t.images&&Array.isArray(t.images)&&t.images.length>0?a=t.images.filter(n=>typeof n=="string"&&n.trim().length>0):t.image_url?a=[t.image_url]:t.thumbnail_url&&(a=[t.thumbnail_url]),a.length===0&&t.video_url){const n=j(t.video_url);n&&(a=[n])}const u=t.content||t.description||"",d=n=>{if(!n)return"";try{return new Date(n).toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}catch{return n}},v=d(t.created_at||new Date().toISOString()),k=t.event_date?d(t.event_date):"",r=p==="pengumuman",i=p==="galeri";`${(t.id||"101").substring(0,8).toUpperCase()}`,`${new Date().getFullYear()}`;const D=e.jsxDEV("div",{id:"printable-portal-root",className:"fixed inset-0 z-[9999] bg-slate-900/90 overflow-y-auto font-serif print:static print:bg-white print:overflow-visible",children:[e.jsxDEV("div",{className:"sticky top-0 z-[10000] bg-white/95 backdrop-blur-md border-b border-slate-200 p-3 sm:p-4 flex justify-between items-center print:hidden shadow-md gap-3",children:[e.jsxDEV(c,{variant:"outline",size:"sm",onClick:b,className:"font-bold text-slate-700 hover:bg-slate-100 rounded-xl h-9",children:[e.jsxDEV(A,{className:"w-4 h-4 mr-1.5"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:112,columnNumber:11},void 0)," Kembali"]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:111,columnNumber:9},void 0),e.jsxDEV("div",{className:"flex items-center gap-2",children:e.jsxDEV(c,{size:"sm",onClick:()=>{N(()=>{window.print()},`${r?"Pengumuman Resmi":i?"Dokumentasi Galeri":"Berita / Artikel"}: ${t.title||"Dokumen"}`)},className:"bg-emerald-600 hover:bg-emerald-700 text-white px-5 font-bold h-9 rounded-xl shadow-md flex items-center gap-2 cursor-pointer text-xs sm:text-sm",children:[e.jsxDEV(_,{className:"w-4 h-4"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:126,columnNumber:13},void 0)," ",e.jsxDEV("span",{children:"Cetak Dokumen"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:126,columnNumber:45},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:116,columnNumber:11},void 0)},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:115,columnNumber:9},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:110,columnNumber:7},void 0),e.jsxDEV("div",{className:"p-4 md:p-8 flex justify-center print:p-0 print:m-0 print:block",children:e.jsxDEV("div",{id:"printable-paper",className:"bg-white shadow-2xl print:shadow-none print:w-full flex flex-col justify-between my-2 print:my-0 text-slate-900 border border-slate-200 print:border-none",style:{width:l==="landscape"?"297mm":"210mm",minHeight:l==="landscape"?"210mm":"297mm",padding:`${m.margin_top||1}cm ${m.margin_right||1}cm ${m.margin_bottom||1}cm ${m.margin_left||1}cm`,boxSizing:"border-box"},children:[e.jsxDEV("div",{children:[x&&e.jsxDEV(V,{},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:145,columnNumber:25},void 0),e.jsxDEV("div",{className:"text-center my-4 font-serif border-b-2 border-slate-900 pb-3",children:[e.jsxDEV("span",{className:"inline-block bg-slate-100 text-slate-800 text-[9.5pt] font-bold px-3.5 py-1 rounded-full uppercase tracking-wider mb-2 border border-slate-300 print:border-slate-400",children:r?"PENGUMUMAN RESMI MADRASAH":i?"DOKUMENTASI & GALERI KEGIATAN MADRASAH":"BERITA & ARTIKEL RESMI MADRASAH"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:149,columnNumber:15},void 0),e.jsxDEV("h1",{className:"text-xl md:text-2xl font-black text-slate-900 mb-1.5 uppercase tracking-tight font-serif leading-snug",children:t.title},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:156,columnNumber:15},void 0),e.jsxDEV("p",{className:"text-[9pt] text-slate-600 italic font-sans",children:["Kategori: ",t.category||(t.video_url||t.media_type==="video"?"Video Dokumentasi":"Foto Galeri Kegiatan"),t.created_at?` • Tanggal Publikasi: ${v}`:"",t.author?` • Oleh: ${t.author}`:""]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:159,columnNumber:15},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:148,columnNumber:13},void 0),r&&(t.event_date||t.event_location||t.event_time)&&e.jsxDEV("div",{className:"mb-6 border-2 border-slate-800 p-4 font-serif text-[10pt] bg-slate-50/50 print:bg-transparent",children:[e.jsxDEV("p",{className:"font-bold text-slate-900 mb-2 border-b border-slate-400 pb-1 uppercase tracking-wide text-xs",children:"📌 RINCIAN PELAKSANAAN / KEGIATAN:"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:169,columnNumber:17},void 0),e.jsxDEV("table",{className:"w-full text-left font-serif border-collapse",children:e.jsxDEV("tbody",{children:[t.event_date&&e.jsxDEV("tr",{children:[e.jsxDEV("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Hari, Tanggal"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:176,columnNumber:25},void 0),e.jsxDEV("td",{className:"py-1 w-4 text-center",children:":"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:177,columnNumber:25},void 0),e.jsxDEV("td",{className:"py-1 text-slate-900",children:k},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:178,columnNumber:25},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:175,columnNumber:23},void 0),t.event_time&&e.jsxDEV("tr",{children:[e.jsxDEV("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Waktu / Jam"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:183,columnNumber:25},void 0),e.jsxDEV("td",{className:"py-1 w-4 text-center",children:":"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:184,columnNumber:25},void 0),e.jsxDEV("td",{className:"py-1 text-slate-900",children:[t.event_time," WIB"]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:185,columnNumber:25},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:182,columnNumber:23},void 0),t.event_location&&e.jsxDEV("tr",{children:[e.jsxDEV("td",{className:"py-1 w-36 font-bold text-slate-900",children:"Tempat / Lokasi"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:190,columnNumber:25},void 0),e.jsxDEV("td",{className:"py-1 w-4 text-center",children:":"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:191,columnNumber:25},void 0),e.jsxDEV("td",{className:"py-1 text-slate-900",children:t.event_location},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:192,columnNumber:25},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:189,columnNumber:23},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:173,columnNumber:19},void 0)},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:172,columnNumber:17},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:168,columnNumber:15},void 0),i&&t.video_url&&e.jsxDEV("div",{className:"mb-6 p-3 bg-slate-50 border border-slate-300 rounded font-sans text-xs",children:[e.jsxDEV("p",{className:"font-bold text-slate-800 flex items-center gap-1.5",children:[e.jsxDEV(S,{className:"w-3.5 h-3.5 text-rose-600"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:204,columnNumber:19},void 0)," Link Video Dokumentasi:"]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:203,columnNumber:17},void 0),e.jsxDEV("p",{className:"text-emerald-700 font-mono underline break-all mt-0.5",children:t.video_url},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:206,columnNumber:17},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:202,columnNumber:15},void 0),u&&e.jsxDEV("div",{className:"text-[11pt] leading-relaxed text-slate-900 whitespace-pre-wrap text-justify mb-6 font-serif",children:u},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:212,columnNumber:15},void 0),h&&a.length>0&&e.jsxDEV("div",{className:"mb-6",children:[i&&e.jsxDEV("div",{className:"flex items-center gap-2 mb-3 pb-1 border-b border-slate-300 font-sans text-xs font-bold text-slate-800",children:[e.jsxDEV(y,{className:"w-4 h-4 text-emerald-700"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:222,columnNumber:21},void 0),e.jsxDEV("span",{children:["DOKUMENTASI FOTO KEGIATAN (",a.length," Foto)"]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:223,columnNumber:21},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:221,columnNumber:19},void 0),a.length===1?e.jsxDEV("div",{className:"relative aspect-[16/9] max-h-[350px] w-full overflow-hidden rounded-lg border border-slate-300 bg-slate-100 print:bg-white my-2 shadow-sm print:shadow-none break-inside-avoid print:break-inside-avoid",children:[e.jsxDEV("img",{src:a[0],alt:t.title,className:"w-full h-full object-cover gallery-img"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:229,columnNumber:21},void 0),e.jsxDEV("span",{className:"absolute bottom-2 left-2 bg-slate-900/80 text-white text-[8pt] px-2 py-0.5 rounded font-sans font-medium print:border print:border-slate-400 print:bg-slate-800",children:"Foto Dokumentasi"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:234,columnNumber:21},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:228,columnNumber:19},void 0):e.jsxDEV("div",{className:"grid grid-cols-2 gap-3.5 my-2",children:a.map((n,s)=>e.jsxDEV("div",{className:"relative aspect-[4/3] w-full rounded-lg border border-slate-300 overflow-hidden bg-slate-100 print:bg-white shadow-sm print:shadow-none break-inside-avoid print:break-inside-avoid",children:[e.jsxDEV("img",{src:n,alt:`${t.title} ${s+1}`,className:"w-full h-full object-cover gallery-img"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:245,columnNumber:25},void 0),e.jsxDEV("span",{className:"absolute bottom-1.5 left-1.5 bg-slate-900/75 text-white text-[7.5pt] px-1.5 py-0.5 rounded font-sans font-medium print:bg-slate-800 print:border print:border-slate-500",children:["Foto ",s+1]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:250,columnNumber:25},void 0)]},s,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:241,columnNumber:23},void 0))},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:239,columnNumber:19},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:219,columnNumber:15},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:143,columnNumber:11},void 0),e.jsxDEV("div",{children:[g&&e.jsxDEV("div",{className:"mt-8 break-inside-avoid",children:e.jsxDEV(B,{showGuru:!1},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:265,columnNumber:17},void 0)},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:264,columnNumber:15},void 0),e.jsxDEV("div",{className:"mt-8 pt-2 border-t border-slate-400 text-[8pt] text-slate-600 flex justify-between items-center font-sans",children:[e.jsxDEV("p",{children:["Dokumen Resmi Madrasah (",i?"Dokumentasi Galeri":r?"Pengumuman":"Artikel",") | Dicetak pada: ",new Date().toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:271,columnNumber:15},void 0),e.jsxDEV("p",{className:"font-semibold",children:"Si@Kad Madrasah"},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:281,columnNumber:15},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:270,columnNumber:13},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:262,columnNumber:11},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:133,columnNumber:9},void 0)},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:132,columnNumber:7},void 0),e.jsxDEV("style",{dangerouslySetInnerHTML:{__html:`
        @media print { 
          /* Completely hide main app container #root and all non-printable elements */
          #root,
          body > *:not(#printable-portal-root),
          .print\\:hidden,
          [class*="print:hidden"] { 
            display: none !important;
            height: 0 !important;
            max-height: 0 !important;
            overflow: hidden !important;
            visibility: hidden !important;
            opacity: 0 !important;
            position: absolute !important;
            top: -99999px !important;
            left: -99999px !important;
          }

          @page { 
            size: A4 ${l}; 
            margin: 8mm 10mm; 
          } 

          html, body { 
            background: #ffffff !important; 
            color: #000000 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            overflow: visible !important;
          } 

          #printable-portal-root,
          div#printable-portal-root,
          body > #printable-portal-root { 
            display: block !important;
            position: static !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
            visibility: visible !important;
            float: none !important;
          } 

          #printable-portal-root * {
            visibility: visible !important;
          }

          #printable-paper { 
            box-shadow: none !important;
            border: none !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            background: #ffffff !important;
            color: #000000 !important;
            display: block !important;
          } 

          #printable-portal-root img.gallery-img {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          #printable-portal-root img:not(.gallery-img) {
            max-width: 100% !important;
            max-height: 10cm !important;
            object-fit: contain !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          .break-inside-avoid,
          [class*="break-inside-avoid"] {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }
        }
      `}},void 0,!1,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:288,columnNumber:7},void 0)]},void 0,!0,{fileName:"/app/applet/src/components/CetakPengumumanBerita.tsx",lineNumber:105,columnNumber:5},void 0);return C.createPortal(D,document.body)};export{O as C,S as V};
