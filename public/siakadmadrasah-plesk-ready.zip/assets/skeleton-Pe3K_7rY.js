import{j as t,v as n}from"./index-Cq6reecN.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
